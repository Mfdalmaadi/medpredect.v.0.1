import React, { useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../store';
import { fetchPatientById } from '../store/slices/patientSlice';
import { fetchPatientHistory } from '../store/slices/predictionSlice';
import { 
  ArrowLeft, 
  Calendar, 
  Phone, 
  FileText, 
  PlusCircle, 
  Activity, 
  HeartPulse, 
  Clock, 
  AlertCircle, 
  Loader2,
  ChevronRight,
  TrendingUp
} from 'lucide-react';

const PatientDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const { currentPatient, loading: patientLoading, error: patientError } = useAppSelector((state) => state.patients);
  const { historyItems: predictions, loading: historyLoading, error: historyError } = useAppSelector((state) => state.predictions);

  useEffect(() => {
    if (id) {
      dispatch(fetchPatientById(id));
      dispatch(fetchPatientHistory({ patientId: id }));
    }
  }, [dispatch, id]);

  const getRiskColor = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'high':
        return 'bg-rose-500/10 text-rose-400 border border-rose-500/25';
      case 'medium':
        return 'bg-amber-500/10 text-amber-400 border border-amber-500/25';
      default:
        return 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25';
    }
  };

  const calculateAge = (dobString: string) => {
    const dob = new Date(dobString);
    const diffMs = Date.now() - dob.getTime();
    const ageDate = new Date(diffMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  };

  const loading = patientLoading || historyLoading;
  const error = patientError || historyError;

  if (loading && !currentPatient) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-indigo-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4">
        <button 
          onClick={() => navigate('/patients')}
          className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" /> Back to registry
        </button>
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/25 flex items-start gap-3 text-rose-400 text-sm">
          <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      </div>
    );
  }

  if (!currentPatient) return null;

  return (
    <div className="space-y-6">
      {/* Back navigation */}
      <button 
        onClick={() => navigate('/patients')}
        className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 transition-colors"
      >
        <ArrowLeft className="h-4 w-4" /> Back to registry
      </button>

      {/* Grid wrapper */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Demographics card */}
        <div className="space-y-6 lg:col-span-1">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Patient Profile</span>
              <h2 className="text-xl font-bold text-white mt-1">
                {currentPatient.first_name} {currentPatient.last_name}
              </h2>
              <span className="inline-flex items-center px-2 py-0.5 mt-2 rounded-full text-xs font-mono bg-slate-950 text-slate-400 border border-slate-800 uppercase">
                {currentPatient.medical_identifier}
              </span>
            </div>

            {/* Demographics details */}
            <div className="space-y-4 border-t border-slate-800/60 pt-6 text-sm">
              <div className="flex items-center gap-3 text-slate-300">
                <Calendar className="h-4 w-4 text-slate-500 shrink-0" />
                <span>
                  {new Date(currentPatient.date_of_birth).toLocaleDateString()} ({calculateAge(currentPatient.date_of_birth)} years old)
                </span>
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <FileText className="h-4 w-4 text-slate-500 shrink-0" />
                <span className="capitalize">Gender: {currentPatient.gender}</span>
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <Phone className="h-4 w-4 text-slate-500 shrink-0" />
                <span>{currentPatient.phone || 'No phone recorded'}</span>
              </div>
            </div>

            {/* Clinical Notes */}
            <div className="border-t border-slate-800/60 pt-6">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-2">Clinical Notes</span>
              <div className="p-3.5 bg-slate-950/40 border border-slate-800/60 rounded-xl text-xs text-slate-400 min-h-20 max-h-40 overflow-y-auto leading-relaxed">
                {currentPatient.notes || 'No clinical remarks recorded for this patient profile.'}
              </div>
            </div>
          </div>

          {/* Diagnostics quick launch panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white">Diagnostic Triggers</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => navigate('/predict/diabetes', { state: { patientId: currentPatient.id } })}
                className="flex flex-col items-center justify-center p-4 bg-emerald-500/5 hover:bg-emerald-500/10 border border-emerald-500/20 hover:border-emerald-500/40 rounded-2xl transition-all duration-300 text-center gap-2 text-xs font-medium text-emerald-400"
              >
                <Activity className="h-5 w-5" />
                Diabetes Check
              </button>
              <button
                onClick={() => navigate('/predict/pcos', { state: { patientId: currentPatient.id } })}
                className="flex flex-col items-center justify-center p-4 bg-pink-500/5 hover:bg-pink-500/10 border border-pink-500/20 hover:border-pink-500/40 rounded-2xl transition-all duration-300 text-center gap-2 text-xs font-medium text-pink-400"
              >
                <HeartPulse className="h-5 w-5" />
                PCOS Check
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Diagnostic history feed */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
            <h3 className="text-lg font-bold text-white mb-6">Diagnostic Evaluation History</h3>
            
            {predictions.length === 0 ? (
              <div className="py-20 text-center text-slate-500 text-sm border border-slate-800 border-dashed rounded-2xl">
                No past prediction reports found for this patient.
              </div>
            ) : (
              <div className="space-y-4">
                {predictions.map((pred) => (
                  <div 
                    key={pred.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-slate-950/40 border border-slate-800 hover:border-indigo-500/30 rounded-2xl transition-all duration-300 gap-4"
                  >
                    {/* Diagnostic summary */}
                    <div className="flex items-start gap-3.5">
                      <div className={`p-2.5 rounded-xl ${
                        pred.disease_type === 'diabetes' 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25' 
                          : 'bg-pink-500/10 text-pink-400 border border-pink-500/25'
                      }`}>
                        {pred.disease_type === 'diabetes' ? <Activity className="h-5 w-5" /> : <HeartPulse className="h-5 w-5" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-200 capitalize">
                            {pred.disease_type} Prediction
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${getRiskColor(pred.risk_level)}`}>
                            {pred.risk_level}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                          <Clock className="h-3 w-3" />
                          {new Date(pred.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Score gauge and navigation */}
                    <div className="flex items-center justify-between sm:justify-end gap-6 border-t sm:border-0 border-slate-800/60 pt-3 sm:pt-0">
                      <div className="text-right">
                        <span className="text-[10px] uppercase font-bold text-slate-500">Evaluation Score</span>
                        <p className="text-sm font-bold text-white">{pred.probability.toLocaleString([], { style: 'percent', minimumFractionDigits: 1 })}</p>
                      </div>
                      <Link
                        to={`/predictions/${pred.id}`}
                        className="flex items-center gap-1 py-1.5 px-3 bg-indigo-600/10 hover:bg-indigo-600 text-indigo-400 hover:text-white rounded-lg border border-indigo-500/20 hover:border-indigo-500 transition-all duration-300 text-xs font-semibold"
                      >
                        Report
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDetail;
