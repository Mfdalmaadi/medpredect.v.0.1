import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../api/client';
import { 
  Users, 
  Activity, 
  AlertTriangle, 
  ShieldCheck, 
  Clock, 
  ChevronRight,
  UserPlus,
  PlusCircle,
  TrendingUp
} from 'lucide-react';
import { useAppSelector } from '../store';

interface RecentActivity {
  type: string;
  title: string;
  resource: string;
  timestamp: string;
}

interface DashboardData {
  scope: string;
  total_users: number;
  total_patients: number;
  total_predictions: number;
  high_risk_predictions: number;
  recent_activity: RecentActivity[];
}

const Dashboard: React.FC = () => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const navigate = useNavigate();
  const { user } = useAppSelector((state) => state.auth);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        const response = await apiClient.get('/dashboard/summary');
        setData(response.data);
        setError(null);
      } catch (err: any) {
        setError(err.response?.data?.detail || 'Failed to load dashboard metrics.');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const getIconForActivity = (type: string) => {
    switch (type.toLowerCase()) {
      case 'prediction':
        return <Activity className="h-4 w-4 text-emerald-400" />;
      case 'patient':
        return <Users className="h-4 w-4 text-indigo-400" />;
      default:
        return <Clock className="h-4 w-4 text-slate-400" />;
    }
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-500 border-t-transparent" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400">
        <p className="font-semibold">Error Loading Dashboard</p>
        <p className="text-sm mt-1">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-indigo-900/40 via-indigo-950/20 to-slate-900 border border-slate-800 p-8 rounded-3xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-2 z-10">
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
            Dashboard
          </h1>
          <p className="text-slate-400 text-sm md:text-base">
            Logged in as clinical {user?.role}. View platform statistics and execute predictions.
          </p>
        </div>
      </div>

      {/* Grid Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Patients */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between shadow-lg relative overflow-hidden group hover:border-indigo-500/30 transition-all duration-300">
          <div className="space-y-1.5 z-10">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Patients</p>
            <p className="text-3xl font-bold text-white">{data?.total_patients || 0}</p>
          </div>
          <div className="p-4 bg-indigo-500/10 text-indigo-400 rounded-2xl group-hover:bg-indigo-500 group-hover:text-white transition-all duration-300">
            <Users className="h-6 w-6" />
          </div>
        </div>

        {/* Total Predictions */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between shadow-lg relative overflow-hidden group hover:border-indigo-500/30 transition-all duration-300">
          <div className="space-y-1.5 z-10">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Predictions Run</p>
            <p className="text-3xl font-bold text-white">{data?.total_predictions || 0}</p>
          </div>
          <div className="p-4 bg-emerald-500/10 text-emerald-400 rounded-2xl group-hover:bg-emerald-500 group-hover:text-white transition-all duration-300">
            <Activity className="h-6 w-6" />
          </div>
        </div>

        {/* High Risk Predictions */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between shadow-lg relative overflow-hidden group hover:border-rose-500/30 transition-all duration-300">
          <div className="space-y-1.5 z-10">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">High Risk Cases</p>
            <p className="text-3xl font-bold text-rose-400">{data?.high_risk_predictions || 0}</p>
          </div>
          <div className="p-4 bg-rose-500/10 text-rose-400 rounded-2xl group-hover:bg-rose-500 group-hover:text-white transition-all duration-300">
            <AlertTriangle className="h-6 w-6" />
          </div>
        </div>

        {/* Total Users (Admin view) / Active Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between shadow-lg relative overflow-hidden group hover:border-indigo-500/30 transition-all duration-300">
          <div className="space-y-1.5 z-10">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {user?.role === 'admin' ? 'Total Users' : 'Platform Scope'}
            </p>
            <p className="text-2xl font-bold text-white capitalize">
              {user?.role === 'admin' ? data?.total_users : data?.scope || 'Doctor'}
            </p>
          </div>
          <div className="p-4 bg-violet-500/10 text-violet-400 rounded-2xl group-hover:bg-violet-500 group-hover:text-white transition-all duration-300">
            <ShieldCheck className="h-6 w-6" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quick Actions Panel */}
        {user?.role !== 'patient' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between shadow-lg">
            <div>
              <h2 className="text-lg font-bold text-white mb-4">Quick Diagnostics</h2>
              <div className="space-y-4">
                <button
                  onClick={() => navigate('/patients')}
                  className="w-full flex items-center justify-between p-4 bg-slate-950/40 hover:bg-slate-800/50 border border-slate-800 hover:border-indigo-500/30 rounded-xl transition-all duration-300 text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
                      <UserPlus className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-200">Patient Registry</p>
                      <p className="text-xs text-slate-500">Register or search clinical profiles</p>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-slate-500 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => navigate('/predict/diabetes')}
                  className="w-full flex items-center justify-between p-4 bg-slate-950/40 hover:bg-slate-800/50 border border-slate-800 hover:border-emerald-500/30 rounded-xl transition-all duration-300 text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
                      <Activity className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-200">Diabetes Assessment</p>
                      <p className="text-xs text-slate-500">Analyze diabetes risk indexes</p>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-slate-500 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => navigate('/predict/pcos')}
                  className="w-full flex items-center justify-between p-4 bg-slate-950/40 hover:bg-slate-800/50 border border-slate-800 hover:border-pink-500/30 rounded-xl transition-all duration-300 text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-pink-500/10 text-pink-400 rounded-lg">
                      <TrendingUp className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-200">PCOS Assessment</p>
                      <p className="text-xs text-slate-500">Evaluate PCOS clinical scoring</p>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-slate-500 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Recent Activity Feed */}
        <div className={`bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg ${user?.role === 'patient' ? 'lg:col-span-3' : 'lg:col-span-2'}`}>
          <h2 className="text-lg font-bold text-white mb-6">Recent Platform Activity</h2>
          {data?.recent_activity.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-sm">
              No recent activity recorded
            </div>
          ) : (
            <div className="relative border-l border-slate-800 pl-6 space-y-6">
              {data?.recent_activity.map((activity, index) => (
                <div key={index} className="relative">
                  {/* Timeline bullet icon */}
                  <span className="absolute -left-10 top-0.5 flex h-7 w-7 items-center justify-center rounded-full bg-slate-900 border border-slate-800 shadow">
                    {getIconForActivity(activity.type)}
                  </span>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-200">{activity.title}</h3>
                    <p className="text-xs text-slate-400 mt-1">Resource ID: {activity.resource}</p>
                    <p className="text-[10px] text-slate-500 mt-1">{formatDate(activity.timestamp)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
