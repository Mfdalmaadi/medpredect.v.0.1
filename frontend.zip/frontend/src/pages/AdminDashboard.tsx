import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '../store';
import { 
  fetchUsers, 
  enableUser, 
  disableUser, 
  fetchAuditLogs, 
  fetchAdminStats 
} from '../store/slices/adminSlice';
import { 
  ShieldCheck, 
  Users, 
  Activity, 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Server, 
  UserX, 
  UserCheck,
  Loader2,
  Lock,
  Unlock,
  Terminal
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const dispatch = useAppDispatch();

  const { 
    users, 
    auditLogs, 
    stats, 
    loading, 
    error 
  } = useAppSelector((state) => state.admin);

  const [activeTab, setActiveTab] = useState<'analytics' | 'users' | 'audit'>('analytics');

  useEffect(() => {
    dispatch(fetchAdminStats());
    dispatch(fetchUsers());
    dispatch(fetchAuditLogs());
  }, [dispatch]);

  const handleToggleStatus = (user: any) => {
    const actionText = user.is_active ? 'disable' : 'enable';
    if (window.confirm(`Are you sure you want to ${actionText} the user account: ${user.email}?`)) {
      if (user.is_active) {
        dispatch(disableUser(user.id));
      } else {
        dispatch(enableUser(user.id));
      }
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-violet-500/10 text-violet-400 border border-violet-500/20';
      case 'doctor':
        return 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20';
      default:
        return 'bg-slate-500/10 text-slate-400 border border-slate-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <ShieldCheck className="h-7 w-7 text-violet-500" />
          Admin Control Center
        </h1>
        <p className="text-slate-400 text-sm mt-1">Monitor platform health, manage user credentials, and review secure audit logs</p>
      </div>

      {/* Tabs Menu */}
      <div className="flex border-b border-slate-800 bg-slate-900/40 p-1.5 rounded-2xl max-w-md">
        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all duration-300 ${
            activeTab === 'analytics' 
              ? 'bg-indigo-600 text-white shadow' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          System Analytics
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all duration-300 ${
            activeTab === 'users' 
              ? 'bg-indigo-600 text-white shadow' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          User Accounts
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all duration-300 ${
            activeTab === 'audit' 
              ? 'bg-indigo-600 text-white shadow' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Security Logs
        </button>
      </div>

      {/* Error alert */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/25 text-rose-400 text-sm">
          {error}
        </div>
      )}

      {/* Tab Panels */}
      {loading && !stats && !users.length && !auditLogs.length ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-indigo-500" />
        </div>
      ) : (
        <>
          {/* ANALYTICS PANEL */}
          {activeTab === 'analytics' && stats && (
            <div className="space-y-8">
              {/* Mini cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Users Count */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Users</p>
                    <p className="text-3xl font-extrabold text-white mt-2">{stats.total_users}</p>
                  </div>
                  <div className="p-3 bg-violet-500/10 text-violet-400 rounded-xl">
                    <Users className="h-6 w-6" />
                  </div>
                </div>

                {/* Active Accounts */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Users</p>
                    <p className="text-3xl font-extrabold text-white mt-2">{stats.active_users}</p>
                  </div>
                  <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
                    <CheckCircle2 className="h-6 w-6" />
                  </div>
                </div>

                {/* Total Patients */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Patients</p>
                    <p className="text-3xl font-extrabold text-white mt-2">{stats.total_patients}</p>
                  </div>
                  <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl">
                    <Users className="h-6 w-6" />
                  </div>
                </div>

                {/* Total Predictions */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Predictions Run</p>
                    <p className="text-3xl font-extrabold text-white mt-2">{stats.total_predictions}</p>
                  </div>
                  <div className="p-3 bg-pink-500/10 text-pink-400 rounded-xl">
                    <Activity className="h-6 w-6" />
                  </div>
                </div>
              </div>

              {/* Advanced charts grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Users Role Breakdown */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow">
                  <h3 className="text-sm font-bold text-white mb-6 uppercase tracking-wider text-slate-400">User Roles Distribution</h3>
                  <div className="space-y-4">
                    {Object.entries(stats.users_by_role).map(([role, count]) => {
                      const percentage = (count / stats.total_users) * 100 || 0;
                      return (
                        <div key={role} className="space-y-1.5">
                          <div className="flex justify-between text-xs font-medium">
                            <span className="capitalize text-slate-300">{role}</span>
                            <span className="text-slate-400 font-semibold">{count} ({percentage.toFixed(0)}%)</span>
                          </div>
                          <div className="h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                            <div style={{ width: `${percentage}%` }} className="h-full bg-indigo-500 rounded-full" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Disease breakdown */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow">
                  <h3 className="text-sm font-bold text-white mb-6 uppercase tracking-wider text-slate-400">Predictions By Diagnostic Model</h3>
                  <div className="space-y-4">
                    {Object.entries(stats.predictions_by_disease).map(([disease, count]) => {
                      const percentage = (count / stats.total_predictions) * 100 || 0;
                      return (
                        <div key={disease} className="space-y-1.5">
                          <div className="flex justify-between text-xs font-medium">
                            <span className="uppercase text-slate-300 font-mono text-[10px]">{disease}</span>
                            <span className="text-slate-400 font-semibold">{count} ({percentage.toFixed(0)}%)</span>
                          </div>
                          <div className="h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                            <div style={{ width: `${percentage}%` }} className="h-full bg-pink-500 rounded-full" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* USER ACCOUNTS PANEL */}
          {activeTab === 'users' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950/40 text-slate-400 text-xs font-semibold uppercase tracking-wider">
                      <th className="px-6 py-4">User ID</th>
                      <th className="px-6 py-4">Email</th>
                      <th className="px-6 py-4">Account Role</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Access Controls</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50 text-sm text-slate-300">
                    {users.map((user) => (
                      <tr key={user.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs text-slate-500">
                          {user.id}
                        </td>
                        <td className="px-6 py-4 font-semibold text-white">
                          {user.email}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${getRoleBadge(user.role)}`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center gap-1 text-xs font-semibold ${
                            user.is_active ? 'text-emerald-400' : 'text-slate-500'
                          }`}>
                            {user.is_active ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                            {user.is_active ? 'Active' : 'Disabled'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => handleToggleStatus(user)}
                            className={`inline-flex items-center gap-1.5 py-1.5 px-3 rounded-lg border text-xs font-semibold transition-all duration-300 ${
                              user.is_active 
                                ? 'bg-rose-500/5 text-rose-400 border-rose-500/20 hover:bg-rose-600 hover:text-white hover:border-rose-500' 
                                : 'bg-emerald-500/5 text-emerald-400 border-emerald-500/20 hover:bg-emerald-600 hover:text-white hover:border-emerald-500'
                            }`}
                          >
                            {user.is_active ? (
                              <>
                                <Lock className="h-3.5 w-3.5" />
                                Disable Access
                              </>
                            ) : (
                              <>
                                <Unlock className="h-3.5 w-3.5" />
                                Enable Access
                              </>
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* AUDIT LOGS PANEL */}
          {activeTab === 'audit' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950/40 text-slate-400 text-xs font-semibold uppercase tracking-wider">
                      <th className="px-6 py-4">Timestamp</th>
                      <th className="px-6 py-4">User</th>
                      <th className="px-6 py-4">Action</th>
                      <th className="px-6 py-4">IP Address</th>
                      <th className="px-6 py-4">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50 text-xs text-slate-300 font-mono">
                    {auditLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="px-6 py-4 text-slate-400 whitespace-nowrap">
                          <span className="flex items-center gap-1.5">
                            <Clock className="h-3.5 w-3.5 text-slate-600" />
                            {new Date(log.created_at).toLocaleString()}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-slate-200">
                          {log.user_email}
                        </td>
                        <td className="px-6 py-4 font-semibold text-indigo-400 whitespace-nowrap">
                          {log.action}
                        </td>
                        <td className="px-6 py-4 text-slate-400 whitespace-nowrap">
                          <span className="flex items-center gap-1.5">
                            <Terminal className="h-3.5 w-3.5 text-slate-600" />
                            {log.ip_address}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-slate-400 max-w-80 truncate" title={log.details}>
                          {log.details}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default AdminDashboard;
