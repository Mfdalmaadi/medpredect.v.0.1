import React, { useState, useEffect, useRef } from 'react';
import { Bell, Menu, CheckCircle } from 'lucide-react';
import { useAppSelector, useAppDispatch } from '../store';
import { fetchNotifications, markNotificationAsRead } from '../store/slices/notificationSlice';

interface NavbarProps {
  onMenuClick: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onMenuClick }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const dispatch = useAppDispatch();
  const { items: notifications, unreadCount } = useAppSelector((state) => state.notifications);
  const { user } = useAppSelector((state) => state.auth);

  useEffect(() => {
    // Initial fetch of notifications
    if (user) {
      dispatch(fetchNotifications({ limit: 5 }));
    }
  }, [dispatch, user]);

  // Handle clicking outside to close the dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMarkRead = (id: string) => {
    dispatch(markNotificationAsRead(id));
  };

  // Helper to format date
  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between px-6">
      {/* Sidebar Mobile Toggle */}
      <button
        onClick={onMenuClick}
        className="p-2 text-slate-400 hover:text-slate-200 lg:hidden rounded-lg hover:bg-slate-800"
      >
        <Menu className="h-6 w-6" />
      </button>

      {/* Title Placeholder / Page Context */}
      <div className="hidden sm:block">
        <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">
          Decision Support System
        </span>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-4">
        {/* Notification Bell Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800 relative transition-all duration-300"
          >
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 h-5 w-5 flex items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white ring-2 ring-slate-900">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notification List Dropdown Panel */}
          {dropdownOpen && (
            <div className="absolute right-0 mt-3 w-80 rounded-2xl border border-slate-800 bg-slate-900 shadow-xl shadow-slate-950/50 overflow-hidden z-50">
              <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                <span className="font-semibold text-sm text-slate-200">Alert Center</span>
                {unreadCount > 0 && (
                  <span className="text-xs text-slate-400">
                    {unreadCount} unread
                  </span>
                )}
              </div>

              {/* Notification rows */}
              <div className="max-h-64 overflow-y-auto divide-y divide-slate-800/50">
                {notifications.length === 0 ? (
                  <div className="px-4 py-6 text-center text-xs text-slate-500">
                    No notifications available
                  </div>
                ) : (
                  notifications.map((notif) => (
                    <div 
                      key={notif.id} 
                      className={`p-3.5 flex gap-3 transition-colors ${
                        notif.is_read ? 'bg-slate-900/40' : 'bg-indigo-500/5 hover:bg-indigo-500/10'
                      }`}
                    >
                      <div className="flex-1 min-w-0">
                        <p className={`text-xs text-slate-300 ${!notif.is_read ? 'font-medium' : ''}`}>
                          {notif.message}
                        </p>
                        <span className="text-[10px] text-slate-500 block mt-1">
                          {formatTime(notif.created_at)}
                        </span>
                      </div>
                      {!notif.is_read && (
                        <button
                          onClick={() => handleMarkRead(notif.id)}
                          className="self-center p-1 text-slate-500 hover:text-indigo-400 rounded-md transition-colors"
                          title="Mark as read"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Vertical Divider */}
        <div className="h-6 w-px bg-slate-800" />

        {/* User Badge */}
        <div className="flex items-center gap-3">
          <div className="hidden md:flex flex-col text-right">
            <span className="text-xs font-semibold text-slate-500 uppercase">Registered User</span>
            <span className="text-sm font-medium text-slate-200 truncate max-w-40">{user?.email}</span>
          </div>
          <div className="h-9 w-9 rounded-full bg-indigo-600 flex items-center justify-center text-white font-semibold text-sm capitalize">
            {user?.email[0] || 'U'}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
