import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  History, 
  ShieldCheck, 
  HeartPulse, 
  Activity,
  LogOut 
} from 'lucide-react';
import { useAppSelector, useAppDispatch } from '../store';
import { logoutUser } from '../store/slices/authSlice';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, setIsOpen }) => {
  const { user } = useAppSelector((state) => state.auth);
  const dispatch = useAppDispatch();

  const handleLogout = () => {
    dispatch(logoutUser());
  };

  const navItems = [
    {
      to: '/dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      allowedRoles: ['admin', 'doctor', 'patient'],
    },
    {
      to: '/patients',
      label: 'Patients',
      icon: Users,
      allowedRoles: ['admin', 'doctor'],
    },
    {
      to: '/predict/diabetes',
      label: 'Diabetes Predict',
      icon: Activity,
      allowedRoles: ['admin', 'doctor'],
    },
    {
      to: '/predict/pcos',
      label: 'PCOS Predict',
      icon: HeartPulse,
      allowedRoles: ['admin', 'doctor'],
    },
    {
      to: '/history',
      label: 'Prediction History',
      icon: History,
      allowedRoles: ['admin', 'doctor', 'patient'],
    },
    {
      to: '/admin',
      label: 'Admin Control',
      icon: ShieldCheck,
      allowedRoles: ['admin'],
    },
  ];

  const filteredItems = navItems.filter(
    (item) => user && item.allowedRoles.includes(user.role)
  );

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-slate-800 bg-slate-900 text-slate-200 transition-transform duration-300 lg:static lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand/Logo Header */}
        <div className="flex h-16 items-center justify-between px-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <HeartPulse className="h-8 w-8 text-indigo-500" />
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-indigo-400 via-indigo-500 to-indigo-600 bg-clip-text text-transparent">
              MedPredict AI
            </span>
          </div>
        </div>

        {/* User Info Capsule */}
        <div className="px-6 py-4 border-b border-slate-800/50 bg-slate-950/20">
          <p className="text-xs text-slate-500 uppercase font-semibold tracking-wider">Session Profile</p>
          <p className="text-sm font-medium text-slate-200 truncate mt-1">{user?.email}</p>
          <span className="inline-flex items-center px-2 py-0.5 mt-2 rounded-full text-xs font-medium bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 capitalize">
            {user?.role}
          </span>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 space-y-1.5 px-4 py-6 overflow-y-auto">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setIsOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                    isActive
                      ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-lg shadow-indigo-600/10'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`
                }
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </NavLink>
            );
          })}
        </nav>

        {/* Footer Logout */}
        <div className="p-4 border-t border-slate-800">
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3.5 px-4 py-3 text-sm font-medium text-rose-400 rounded-xl hover:bg-rose-500/10 transition-all duration-300"
          >
            <LogOut className="h-5 w-5" />
            Sign Out
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
