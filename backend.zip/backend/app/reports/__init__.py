"""Report generation package."""
